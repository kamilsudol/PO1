#include "vector.h"

using namespace MyStuff;
/*
std::ostream &operator<<(std::ostream &out, vector &A){
    for(int i=0;i<A.size();i++){
        out << A.tab[i]<< " ";
    }
    return out;
}*/
/*
vector::vector(int a):siz(a){
    tab=new int[a];
    for(int i=0;i<a;i++){
        tab[i]=0;
}*/
